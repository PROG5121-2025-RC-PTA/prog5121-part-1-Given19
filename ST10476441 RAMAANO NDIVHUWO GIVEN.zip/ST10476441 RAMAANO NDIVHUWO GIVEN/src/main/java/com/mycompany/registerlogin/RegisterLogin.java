/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.registerlogin;

/**
 *
 * @author RC_Student_lab
 */
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;
import java.util.UUID;

public class RegisterLogin {
    private static final Scanner input = new Scanner(System.in);
    private static final Map<String, AccountDetails> accountDatabase = new TreeMap<>();
    private static final List<MessageLog> chatHistory = new ArrayList<>();
    
    public static void main(String[] args) {
        displayWelcomeBanner();
        
        boolean applicationRunning = true;
        while (applicationRunning) {
            displayMainMenu();
            String selection = input.nextLine().trim();
            
            switch (selection) {
                case "1":
                    createNewAccount();
                    break;
                case "2":
                    authenticateUser();
                    break;
                case "3":
                    applicationRunning = false;
                    System.out.println("\nExiting application. Thank you for using MessengerSystem!");
                    break;
                default:
                    System.out.println("\n[ERROR] Invalid selection. Please try again.");
            }
        }
    }
    
    private static void displayWelcomeBanner() {
        System.out.println("*");
        System.out.println("*          WELCOME TO MESSENGER SYSTEM          *");
        System.out.println("*");
        System.out.println("\nAccount Creation Requirements:");
        System.out.println("- Identifier must contain an underscore (_) and be 5 or fewer characters");
        System.out.println("- Security code must be at least 8 characters with one uppercase letter,");
        System.out.println("  one digit, and one special character");
        System.out.println("- Contact number must include country code (+) and maximum 10 digits");
        System.out.println("*");
    }
    
    private static void displayMainMenu() {
        System.out.println("\nMAIN MENU");
        System.out.println("1. Create Account");
        System.out.println("2. Access Account");
        System.out.println("3. Exit Application");
        System.out.print("\nSelect an option (1-3): ");
    }
    
    private static void createNewAccount() {
        System.out.println("\n--- ACCOUNT CREATION ---");
        
        // Collect user identifier
        System.out.print("Enter identifier: ");
        String identifier = input.nextLine().trim();
        
        // Collect security code
        System.out.print("Enter security code: ");
        String securityCode = input.nextLine().trim();
        
        // Collect contact number
        System.out.print("Enter contact number (with country code, e.g., +12025550179): ");
        String contactNumber = input.nextLine().trim();
        
        // Collect personal details
        System.out.print("Enter given name: ");
        String givenName = input.nextLine().trim();
        
        System.out.print("Enter family name: ");
        String familyName = input.nextLine().trim();
        
        // Validate and create account
        AccountValidator validator = new AccountValidator();
        
        if (!validator.isValidIdentifier(identifier)) {
            System.out.println("\n[ERROR] Invalid identifier format. Must contain an underscore and be 5 or fewer characters.");
            return;
        }
        
        if (!validator.isValidSecurityCode(securityCode)) {
            System.out.println("\n[ERROR] Invalid security code. Must be at least 8 characters with one uppercase letter,");
            System.out.println("one digit, and one special character.");
            return;
        }
        
        if (!validator.isValidContactNumber(contactNumber)) {
            System.out.println("\n[ERROR] Invalid contact number. Must include country code (+) and be 10 or fewer digits.");
            return;
        }
        
        if (accountDatabase.containsKey(identifier)) {
            System.out.println("\n[ERROR] This identifier is already in use. Please choose another one.");
            return;
        }
        
        // Create and store account
        AccountDetails newAccount = new AccountDetails(identifier, securityCode, contactNumber, givenName, familyName);
        accountDatabase.put(identifier, newAccount);
        
        System.out.println("\n[SUCCESS] Account created successfully!");
        System.out.println("- Identifier registered: " + identifier);
        System.out.println("- Security code set successfully");
        System.out.println("- Contact number registered: " + contactNumber);
    }
    
    private static void authenticateUser() {
        System.out.println("\n--- ACCOUNT ACCESS ---");
        
        System.out.print("Enter identifier: ");
        String identifier = input.nextLine().trim();
        
        System.out.print("Enter security code: ");
        String securityCode = input.nextLine().trim();
        
        AccountDetails account = accountDatabase.get(identifier);
        
        if (account != null && account.verifyCredentials(identifier, securityCode)) {
            System.out.println("\n[SUCCESS] Authentication successful!");
            System.out.println("Welcome back, " + account.getGivenName() + " " + account.getFamilyName() + "!");
            startMessagingSession(account);
        } else {
            System.out.println("\n[ERROR] Authentication failed. Invalid identifier or security code.");
        }
    }
    
    private static void startMessagingSession(AccountDetails account) {
        System.out.println("\n--- MESSAGING SESSION ---");
        System.out.println("Type 'help' for commands or 'exit' to end session");
        
        boolean sessionActive = true;
        while (sessionActive) {
            System.out.print("\n" + account.getIdentifier() + " > ");
            String message = input.nextLine().trim();
            
            if (message.equalsIgnoreCase("exit")) {
                sessionActive = false;
                System.out.println("Ending messaging session...");
            } else if (message.equalsIgnoreCase("help")) {
                displayHelpMenu();
            } else if (message.equalsIgnoreCase("save")) {
                saveMessagesToFile(account);
            } else if (!message.isEmpty()) {
                // Log the message
                MessageLog log = new MessageLog(account.getIdentifier(), message);
                chatHistory.add(log);
                
                // Generate response
                String response = generateResponse(message, account.getGivenName());
                System.out.println("System > " + response);
            }
        }
    }
    
    private static void displayHelpMenu() {
        System.out.println("\n--- AVAILABLE COMMANDS ---");
        System.out.println("exit - End the messaging session");
        System.out.println("help - Display this help menu");
        System.out.println("save - Save conversation to a file");
    }
    
    private static String generateResponse(String message, String userName) {
        // Simple response generation based on message content
        if (message.toLowerCase().contains("hello") || message.toLowerCase().contains("hi")) {
            return "Hello there, " + userName + "! How can I assist you today?";
        } else if (message.toLowerCase().contains("how are you")) {
            return "I'm functioning well, thank you for asking! How about you?";
        } else if (message.toLowerCase().contains("bye") || message.toLowerCase().contains("goodbye")) {
            return "Goodbye! Feel free to chat again anytime.";
        } else if (message.toLowerCase().contains("thank")) {
            return "You're welcome! Is there anything else you'd like to discuss?";
        } else if (message.contains("?")) {
            return "That's an interesting question. Let me think about it...";
        } else {
            return "I understand you said: \"" + message + "\". Please tell me more.";
        }
    }
    
    private static void saveMessagesToFile(AccountDetails account) {
        try {
            String fileName = "chat_" + account.getIdentifier() + "_" + 
                             UUID.randomUUID().toString().substring(0, 8) + ".txt";
            
            File file = new File(fileName);
            BufferedWriter writer = new BufferedWriter(new FileWriter(file));
            
            writer.write("Chat History for " + account.getGivenName() + " " + account.getFamilyName());
            writer.newLine();
            writer.write("Generated on: " + 
                        LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
            writer.newLine();
            writer.write("----------------------------------------");
            writer.newLine();
            
            for (MessageLog log : chatHistory) {
                if (log.getSender().equals(account.getIdentifier())) {
                    writer.write(log.getFormattedMessage());
                    writer.newLine();
                }
            }
            
            writer.close();
            System.out.println("Chat history saved to " + fileName);
            
        } catch (IOException e) {
            System.out.println("[ERROR] Failed to save chat history: " + e.getMessage());
        }
    }
}

class AccountDetails {
    private final String identifier;
    private final String securityCode;
    private final String contactNumber;
    private final String givenName;
    private final String familyName;
    private final LocalDateTime creationDate;
    
    public AccountDetails(String identifier, String securityCode, String contactNumber, 
                          String givenName, String familyName) {
        this.identifier = identifier;
        this.securityCode = securityCode;
        this.contactNumber = contactNumber;
        this.givenName = givenName;
        this.familyName = familyName;
        this.creationDate = LocalDateTime.now();
    }
    
    public boolean verifyCredentials(String identifier, String securityCode) {
        return this.identifier.equals(identifier) && this.securityCode.equals(securityCode);
    }
    
    public String getIdentifier() {
        return identifier;
    }
    
    public String getContactNumber() {
        return contactNumber;
    }
    
    public String getGivenName() {
        return givenName;
    }
    
    public String getFamilyName() {
        return familyName;
    }
    
    public LocalDateTime getCreationDate() {
        return creationDate;
    }
}

class AccountValidator {
    public boolean isValidIdentifier(String identifier) {
        return identifier != null && identifier.contains("_") && identifier.length() <= 5;
    }
    
    public boolean isValidSecurityCode(String securityCode) {
        if (securityCode == null || securityCode.length() < 8) {
            return false;
        }
        
        boolean hasUppercase = !securityCode.equals(securityCode.toLowerCase());
        boolean hasDigit = securityCode.matches(".*\\d.*");
        boolean hasSpecial = securityCode.matches(".*[^A-Za-z0-9].*");
        
        return hasUppercase && hasDigit && hasSpecial;
    }
    
    public boolean isValidContactNumber(String contactNumber) {
    if (contactNumber == null || !contactNumber.startsWith("+")) {
        return false;
    }
    
    // Remove the + sign first
    String withoutPlus = contactNumber.substring(1);
    
    // Check that the rest contains only digits
    if (!withoutPlus.matches("\\d+")) {
        return false;
    }
    
    // Check the length of just the digits (after removing the + sign)
    return withoutPlus.length() <= 11;
}
    
  
}

class MessageLog {
    private final String sender;
    private final String content;
    private final LocalDateTime timestamp;
    
    public MessageLog(String sender, String content) {
        this.sender = sender;
        this.content = content;
        this.timestamp = LocalDateTime.now();
    }
    
    public String getSender() {
        return sender;
    }
    
    public String getContent() {
        return content;
    }
    
    public LocalDateTime getTimestamp() {
        return timestamp;
    }
    
    public String getFormattedMessage() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
        return "[" + timestamp.format(formatter) + "] " + sender + ": " + content;
    }
}
