/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package com.mycompany.registerlogin;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

public class RegisterLoginTest {
    
    private AccountValidator validator;
    
    @Before
    public void setUp() {
        validator = new AccountValidator();
    }
    
    // Username Tests
    
    @Test
    public void testUsernameCorrectlyFormatted() {
        // Test Data: "kyl_1"
        assertTrue("Username should be valid when it contains an underscore and is 5 or fewer characters",
                validator.isValidIdentifier("kyl_1"));
    }
    
    @Test
    public void testUsernameIncorrectlyFormatted_NoUnderscore() {
        // Test Data: "kyle!"
        assertFalse("Username should be invalid when it doesn't contain an underscore",
                validator.isValidIdentifier("kyle!"));
    }
    
    @Test
    public void testUsernameIncorrectlyFormatted_TooLong() {
        // Test Data: "kyle_12"
        assertFalse("Username should be invalid when it's longer than 5 characters",
                validator.isValidIdentifier("kyle_12"));
    }
    
    @Test
    public void testUsernameIncorrectlyFormatted_BothIssues() {
        // Test Data: "kyle!!!!!!"
        assertFalse("Username should be invalid when it has no underscore and is too long",
                validator.isValidIdentifier("kyle!!!!!"));
    }
    
    // Password (Security Code) Tests
    
    @Test
    public void testPasswordMeetsComplexityRequirements() {
        // Test Data: "Ch&&sec@ke99!"
        assertTrue("Password should be valid when it meets all complexity requirements",
                validator.isValidSecurityCode("Ch&&sec@ke99!"));
    }
    
    @Test
    public void testPasswordDoesNotMeetComplexityRequirements_TooShort() {
        // Test Data: "Pass1!"
        assertFalse("Password should be invalid when it's shorter than 8 characters",
                validator.isValidSecurityCode("Pass1!"));
    }
    
    @Test
    public void testPasswordDoesNotMeetComplexityRequirements_NoCapital() {
        // Test Data: "password1!"
        assertFalse("Password should be invalid when it has no uppercase letter",
                validator.isValidSecurityCode("password1!"));
    }
    
    @Test
    public void testPasswordDoesNotMeetComplexityRequirements_NoNumber() {
        // Test Data: "Password!"
        assertFalse("Password should be invalid when it has no digit",
                validator.isValidSecurityCode("Password!"));
    }
    
    @Test
    public void testPasswordDoesNotMeetComplexityRequirements_NoSpecialChar() {
        // Test Data: "Password1"
        assertFalse("Password should be invalid when it has no special character",
                validator.isValidSecurityCode("Password1"));
    }
    
    @Test
    public void testPasswordDoesNotMeetComplexityRequirements_AllIssues() {
        // Test Data: "password"
        assertFalse("Password should be invalid when it fails all requirements",
                validator.isValidSecurityCode("password"));
    }
    
    // Phone Number Tests
    
    @Test
    public void testPhoneNumberCorrectlyFormatted() {
        // Test Data: "+27838968976"
        assertTrue("Phone number should be valid with correct format",
                validator.isValidContactNumber("+27838968976"));
    }
    
    @Test
    public void testPhoneNumberIncorrectlyFormatted_NoCountryCode() {
        // Test Data: "08966553"
        assertFalse("Phone number should be invalid without country code",
                validator.isValidContactNumber("08966553"));
    }
    
    @Test
    public void testPhoneNumberIncorrectlyFormatted_TooManyDigits() {
        // Test Data: "+278389689760123"
        assertFalse("Phone number should be invalid with too many digits",
                validator.isValidContactNumber("+278389689760123"));
    }
    
    // Integration Tests
    
    @Test
    public void testSuccessfulAccountCreation() {
        // Create an account with valid details
        AccountDetails account = new AccountDetails("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Kyle", "Smith");
        
        // Verify the account details were stored correctly
        assertEquals("kyl_1", account.getIdentifier());
        assertEquals("+27838968976", account.getContactNumber());
        assertEquals("Kyle", account.getGivenName());
        assertEquals("Smith", account.getFamilyName());
    }
    
    @Test
    public void testSuccessfulLogin() {
        // Create an account
        AccountDetails account = new AccountDetails("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Kyle", "Smith");
        
        // Test login credentials
        assertTrue("Login should succeed with correct credentials",
                account.verifyCredentials("kyl_1", "Ch&&sec@ke99!"));
    }
    
    @Test
    public void testFailedLogin_WrongUsername() {
        // Create an account
        AccountDetails account = new AccountDetails("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Kyle", "Smith");
        
        // Test login with wrong username
        assertFalse("Login should fail with incorrect username",
                account.verifyCredentials("wrong", "Ch&&sec@ke99!"));
    }
    
    @Test
    public void testFailedLogin_WrongPassword() {
        // Create an account
        AccountDetails account = new AccountDetails("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Kyle", "Smith");
        
        // Test login with wrong password
        assertFalse("Login should fail with incorrect password",
                account.verifyCredentials("kyl_1", "wrongpass"));
    }
    
    // Message formatting tests with predefined expected messages
    
    @Test
    public void testWelcomeMessageForValidUser() {
        AccountDetails account = new AccountDetails("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Kyle", "Smith");
        String expectedMessage = "Welcome Kyle Smith, it is great to see you.";
        String actualMessage = "Welcome " + account.getGivenName() + " " + account.getFamilyName() + ", it is great to see you.";
        
        assertEquals(expectedMessage, actualMessage);
    }
    
    @Test
    public void testPasswordSuccessMessage() {
        String validPassword = "Ch&&sec@ke99!";
        boolean isValid = validator.isValidSecurityCode(validPassword);
        
        assertTrue("Password should meet complexity requirements", isValid);
        
        // This would be the message displayed in the real system
        String systemMessage = "Password successfully captured";
        assertEquals("Password successfully captured", systemMessage);
    }
    
    @Test
    public void testPasswordErrorMessage() {
        String invalidPassword = "password";
        boolean isValid = validator.isValidSecurityCode(invalidPassword);
        
        assertFalse("Password should not meet complexity requirements", isValid);
        
        // This would be the error message displayed in the real system
        String errorMessage = "Password is not correctly formatted, please ensure that the password contains at least eight characters, a capital letter, a number and a special character";
        assertEquals("Password is not correctly formatted, please ensure that the password contains at least eight characters, a capital letter, a number and a special character", errorMessage);
    }
    
    @Test
    public void testPhoneNumberSuccessMessage() {
        String validPhoneNumber = "+27838968976";
        boolean isValid = validator.isValidContactNumber(validPhoneNumber);
        
        assertTrue("Phone number should be valid", isValid);
        
        // This would be the message displayed in the real system
        String systemMessage = "Cell number successfully captured";
        assertEquals("Cell number successfully captured", systemMessage);
    }
    
    @Test
    public void testPhoneNumberErrorMessage() {
        String invalidPhoneNumber = "08966553";
        boolean isValid = validator.isValidContactNumber(invalidPhoneNumber);
        
        assertFalse("Phone number should be invalid", isValid);
        
        // This would be the error message displayed in the real system
        String errorMessage = "Cell phone number is incorrectly formatted or does not contain an international code, please correct and try again";
        assertEquals("Cell phone number is incorrectly formatted or does not contain an international code, please correct and try again", errorMessage);
    }
    
    @Test
    public void testUsernameErrorMessage() {
        String invalidUsername = "kyle!!!!!";
        boolean isValid = validator.isValidIdentifier(invalidUsername);
        
        assertFalse("Username should be invalid", isValid);
        
        // This would be the error message displayed in the real system
        String errorMessage = "Username is not correctly formatted, please ensure that your username contains an underscore and is not more than five characters in length.";
        assertEquals("Username is not correctly formatted, please ensure that your username contains an underscore and is not more than five characters in length.", errorMessage);
    }
}
